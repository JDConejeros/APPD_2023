########################################################################/
# Web-Scraping y APIS ------
# APPDD - 10/06/2023
########################################################################/
# José Daniel Conejeros - jdconejeros@uc.cl
########################################################################/

# En este código aplicaremos algunos temas de programación funcional 

########################################################################/
# 1. Librerias y datos -------------
########################################################################/

# Desactivar notación científica y limpiar la memoria
options(scipen=999)
rm(list=(ls()))

# Vamos a cargar las las librerías 
#install.packages("") # Puedes escribir entre las comillas sino tienes instalada alguna librería
library(rio)      # Importar BBDD
library(dplyr)    # Manipulación de datos
library(tidyr)    # Manipulación de tablas
library(purrr)    # Programación funcional
library(ggplot2)  # Aplicamos a nuestros datos 
library(patchwork) # Compactar figuras
library(stm) # Visualizar series de tiempo
library(stringr) # Trabajo con texto
library(tm) # Trabajo con texto

########################################################################/
# 2.  Extracción vía webscraping -------------
########################################################################/

# Cargamos las librerías necesarias
install.packages("rvest")
install.packages("robotstxt")
library(rvest)
library(robotstxt)

# read_html() para descargar el html
# html_nodes() para seleccionar nodos
# html_text() para extraer el texto dentro de los nodos
# html_attr() para extraer algún atributo del nodo
# html_table() para extraer tablas
######################################################/
## 2.1 Primera extracción desde nuestro html ----
######################################################/

# Leemos el html 
url <- "input/Ejemplo.html"
url_html <- read_html(url)

# Extramos el título
url_html %>%
  html_nodes("h1")%>%
  html_text()

# Extraemos párrafos
url_html %>% 
  html_nodes("p") %>%
  html_text()

# Extraemos párrafos con id
url_html %>%
  html_nodes("#first") %>%
  html_text()

# Extraemos hipervínculos
url_html %>%
  html_nodes("a") %>%
  html_attr("href")

######################################################/
## 2.2 Segunda extracción desde un html real ----
######################################################/

# Veamos un ejemplo simple desde wikipedia
wikipedia <- get_robotstxt("https://es.wikipedia.org/wiki/Pandemia_de_COVID-19_en_Chile") # Todo está disponible y aplica para todas las páginas subyacentes
wikipedia
r_parsed <- parse_robotstxt(wikipedia)
r_parsed # Al parecer esta todo disponible para el uso

# Aplicamos el webscraping
url_2 <- "https://es.wikipedia.org/wiki/Pandemia_de_COVID-19_en_Chile"

contenido <- read_html(url_2)
tablas <- contenido %>%
  html_table()

# Extraemos la información de una lista
tabla <- tablas[[12]] 
tablas[[13]] 

# Ejercicio propuesto: ¿qué modificaciones harían a esta tabla

######################################################/
## 2.3 Extracciones de datos más complejas ----
######################################################/

# Librerías para trabajar
library(tidyverse) # Funciones para la manipulación y visualización de datos
library(gtrendsR)  # Funciones para extraer consultas de google 

t <- '2022-01-01 2022-12-31' # tiempo
c <- 'CL' # ubicación

AR <- gtrends(keyword = c('gripe', 'tapsin'), geo = c, time = t) # Limitación max 5 términos al mismo tiempo

# Los search hits representan la popularidad relativa de un término de búsqueda en comparación con otros términos dentro del mismo período
AR$interest_over_time$hits <- ifelse(AR$interest_over_time$hits == "<1", 0, AR$interest_over_time$hits)
AR$interest_over_time$hits <- as.numeric(AR$interest_over_time$hits)

# último día
AR$interest_over_time %>% arrange(date) %>% pull(date) %>% max()

# Veamos una gráfica
AR$interest_over_time %>%
  mutate(hits = as.numeric(hits)) %>%
  ggplot(aes(x=as.Date(date), y=hits, color = keyword)) +
  scale_x_date(date_breaks = "4 week") +
  geom_path() +
  labs(title = "Alergia y gripe en búsquedas de Google") +
  theme_minimal()

######################################################/
## 2.4 Extracciones de datos más complejas ----
######################################################/

# Registro de congresistas históricos
congreso <- get_robotstxt("https://www.bcn.cl/historiapolitica/corporaciones/periodos_legislativos_index") # Todo está disponible y aplica para todas las páginas subyacentes
congreso
r_parsed <- parse_robotstxt(congreso)
r_parsed # Al parecer esta todo disponible para el uso

# Identificar urls de periodos
cong_html <- read_html("https://www.bcn.cl/historiapolitica/corporaciones/periodos_legislativos_index")
links_periodos <- cong_html %>% html_nodes("#nav li:nth-child(1) a") %>% html_attr("href")
links_periodos <- links_periodos[-length(links_periodos)]
links_periodos <- paste0("https://www.bcn.cl", links_periodos)
links_periodos

# Función read_html() de rvest, pero usando safely() de purr para que no se detenga cuando un link no funciona
safe_html <- safely(read_html, otherwise = NULL, quiet = F)

# Por periodo extraer todos los congresos
# map es como lapply, pero de purrr (tidyverse)
# Sys.sleep fuerza a esperar antes de iniciar la siguiente vuelta; esto es para no sobrecargar el servidor
# El  punto . es cada uno de los elementos de nuestro vector, como el i en un loop
# La virgulilla (~) indica que lo que sigue es una función. Es como el function(x) de lapply

cong_html_2 <- links_periodos %>% 
  map(~{
    Sys.sleep(sample(seq(1, 3, by=0.001), 1))
    safe_html(.)
  })

# Veamos el resultado
cong_html_2[1:3]

# Con discard() elimininanos registros que arrojaron error
links_periodos_2 <- discard(cong_html_2, ~ is.null(.$result)) %>%
  map(~ .$result %>% {
    links <- html_nodes(., "#myTabContent .col-md-4 a") %>% html_attr("href")
    links <- paste0("https://www.bcn.cl", links)
  })

# 1810 y dictadura son períodos con formatos especiales, donde no hay congresos regulares. Los sacamos.
links_periodos_2 <- links_periodos_2[-c(1,7)]

# Desanidamos
links_periodos_2 <- unlist(links_periodos_2)

# Luego anidamos de nuevo en listas, pero esta vez sin capas más profundas
links_periodos_2 <- as.list(links_periodos_2)
links_periodos_2[1:10] # Esto nos deja nuestros links de extracción

#Esta es la parte más demorosa. Tenemos 162 links de períodos (para diputados y senadores)
#vamos a ir página por página descargando datos de membresía

# Sys.time nos da la hora. En este caso el inicio
time_cong_1 <- Sys.time() 

time_cong_1

cong_html_3 <- links_periodos_2[1:5] %>% 
  map(~{
    Sys.sleep(sample(seq(1, 3, by=0.001), 1))
    safe_html(.)})

time_cong_2 <- Sys.time()

paste("La descarga de 162 páginas demoró", round(abs(time_cong_1 - time_cong_2), 1), "mins")
# "La descarga de 162 páginas demoró 28.4 mins"

# Armamos la tabla final 
# Primero, descartamos todas las descargas que arrojaron error; lo resultante lo alimentamos a map_df()
# Entonces, buscamos nodos a cada elemento de la lista result
# Si el elemento está vación (tiene length() === 0), entonces, lo reemplazamos por un NA
# Finalmente, lo juntamos todo en una tabla tibble, donde cada vector es una columna de la tabla resultante

cong_df_2 <- discard(cong_html_3, ~ is.null(.$result)) %>%
  map_df(~ .$result %>% {
    Name <- html_nodes(., ".clearfix h5") %>% html_text()
    Name <- if (length(Name) == 0) NA else Name
    Period <- html_nodes(., ".text-title") %>% html_text()
    Period <- if (length(Period) == 0) NA else Period
    Period <- trimws(Period)
    Localidad <- html_nodes(., ".clearfix .localidad") %>% html_text()
    Localidad <- if (length(Localidad) == 0) NA else Localidad
    Varios <- html_nodes(., ".clearfix small") %>% html_text()
    Varios <- if (length(Varios) == 0) NA else Varios
    
    df <- tibble(Name, Period,Localidad,Varios)
  })

# Limpiamos las columnas 
# Lamentablemente este proceso tiene que ser manual¡
cong_df_2$Varios <- trimws(cong_df_2$Varios)
cong_df_2$Period <- sapply(strsplit(cong_df_2$Period, " "), function(x) paste(x[1:3], collapse = " "))
cong_df_2$Camara <- sapply(strsplit(cong_df_2$Varios, "|", fixed = T), function(x) x[1])
cong_df_2$Varios <- removeWords(cong_df_2$Varios, c("Diputado", "Senador", "Propietario", "Suplente", "Suplentes", "Consejero","Vitalicio", "Plenipotenciarios", "Subrogante","Institucional"))
cong_df_2$Partido <- ifelse(sapply(strsplit(cong_df_2$Varios, "|", fixed = T), length) == 3, sapply(strsplit(cong_df_2$Varios, "|", fixed = T), function(x) x[3]), NA)
cong_df_2$Varios <- sapply(strsplit(cong_df_2$Varios, "|", fixed = T), function(x) paste(x[1:2], collapse = " "))
cong_df_2$Varios <- trimws(cong_df_2$Varios)
cong_df_2$Name <- trimws(cong_df_2$Name)
cong_df_2$Period <- trimws(cong_df_2$Period)
cong_df_2$Localidad <- trimws(cong_df_2$Localidad)
cong_df_2$Camara <- trimws(cong_df_2$Camara)
cong_df_2$Partido <- trimws(cong_df_2$Partido)
cong_df_2 <- cong_df_2[, -4]
cong_df_2$Start <- as.numeric(sapply(strsplit(cong_df_2$Period, ""), function(x) paste0(x[7:10], collapse = "")))
cong_df_2$End <- as.numeric(sapply(strsplit(cong_df_2$Period, ""), function(x) paste0(x[20:23], collapse = "")))
cong_df_2 <- cong_df_2[!is.na(cong_df_2$Name),]
cong_df_2$Tipo <- ifelse(sapply(strsplit(cong_df_2$Camara, " "), length) == 2, sapply(strsplit(cong_df_2$Camara, " "), function(x) x[2]), NA)
cong_df_2$Camara <- sapply(strsplit(cong_df_2$Camara, " "), "[", 1)
cong_df_2 <- cong_df_2[, c(1,2,6,7,4,8,3,5)]
cong_df_2 <- sapply(cong_df_2, function(x) chartr("áéíóúÁÉÍÓÚ", "aeiouAEIOU", x))
cong_df_2 <- as.data.frame(cong_df_2)
cong_df_2$Name <- as.character(cong_df_2$Name)
cong_df_2$Period <- as.character(cong_df_2$Period)
cong_df_2$Start <- as.numeric(as.character(cong_df_2$Start))
cong_df_2$End <- as.numeric(as.character(cong_df_2$End))
cong_df_2$Camara <- as.character(cong_df_2$Camara)
cong_df_2$Tipo <- as.character(cong_df_2$Tipo)
cong_df_2$Localidad <- as.character(cong_df_2$Localidad)
cong_df_2$Partido <- as.character(cong_df_2$Partido)
cong_df_2 <- cong_df_2[order(cong_df_2$Start) & order(cong_df_2$End),]
cong_df_2 <- cong_df_2[!duplicated(cong_df_2),]
cong_df_2$Partido[grepl("Partidlo Liberal", cong_df_2$Partido)] <- "Partido Liberal"
cong_df_2$Partido[grepl("Partido Por la Democracia", cong_df_2$Partido)] <- "Partido por la Democracia"
cong_df_2$Partido[grepl("Partido Radical Social Democrata", cong_df_2$Partido)] <- "Partido Radical Socialdemocrata"
cong_df_2$Partido <- str_squish(cong_df_2$Partido)

# Veamos la data final 
View(cong_df_2)
min(cong_df_2$Start)
max(cong_df_2$End)

# Con esto ya tenemos nuestros datos listos
# Generemos una figura
apellidos_viejos <- "Errazuriz|Vicuña|Larrain|Arao|Vivar|Cerda|Concha|Egaña|Gandarillas|Marin|Tagle|Portales|Cienfuegos|Salas|Infante|Alcalde|Aranguiz|Astorga|Benavente|Binimelis|Calvo|Campino|Aranguiz|Echeverria|Elizondo|Goycoolea|Recabarren|Rozas|Lastra|Alcazar|Salcedo|Eyzaguirre|Manzano|Gallo|Palma|Jaraquemada|Guzman|Lecaros|Barra|Mascayano|O'Higgins|Orihuela|Ovalle|Cotapos|Rosales|Ugarte|Urrejola|Urrutia|Valdivieso|Vergara|Vial"

cong_df_2 %>%
  group_by(Start)%>%
  summarise(Proportion = sum(grepl(apellidos_viejos, Name))/n()) %>%
  ggplot(aes(Start, Proportion))+
  geom_path(data = . %>% filter(Start>1831 & Start<1974))+
  geom_path(data = . %>% filter(Start>1970 & Start < 1991),linetype = "dashed")+
  geom_path(data = . %>% filter(Start>1989))+
  geom_rect(xmin = 1879, xmax = 1883, ymin = -Inf, ymax = Inf, fill = "black", alpha = 1/256)+
  geom_rect(xmin = 1924, xmax = 1926, ymin = -Inf, ymax = Inf, fill = "black", alpha = 1/256)+
  geom_rect(xmin = 1973, xmax = 1990, ymin = -Inf, ymax = Inf, fill = "black", alpha = 1/256)+
  geom_text(aes(1861, 0.4), label = "Portalian", size = 3)+
  geom_text(aes(1903, 0.4), label = "Parliamentarian", size = 3)+
  geom_text(aes(1951, 0.4), label = "Developmental", size = 3)+
  geom_text(aes(2006, 0.4), label = "Neoliberal", size = 3)+
  geom_text(aes(1881, 0.05), label = "Nitrate War", size = 3)+
  geom_text(aes(1925, 0.05), label = "1925 Constitution", size = 3)+
  geom_text(aes(1981, 0.05), label = "Dictatorship", size = 3)+
  theme_classic()+
  labs(title = "Las familias fundadoras en el congreso chileno, 1834-2018")

########################################################################/
# 3.  API's -------------
########################################################################/

rm(list=(ls())) # Limpiemos la memoria 
# Para trabajar en una API siempre es bueno loggearse a la web de extracción 
# Como las funciones obtienen información en Internet en tiempo real, ¡el tiempo de ejecución depende de su conexión a Internet!
# Más información: https://rapidapi.com/hub

install.packages("httr") # Para trabajar extracciones básicas
library(httr)
config(http2 = TRUE)

## 3.1 httr (básico) ----

url <- "https://world-history-timeline.p.rapidapi.com/History-By-Year"

queryString <- list(year = "1990")

response <- VERB("GET", url, query = queryString, add_headers('X-RapidAPI-Key' = 'c7b4cf08fdmsh183d3c50825def1p13f8fbjsnb74b69af4265', 
                                                              'X-RapidAPI-Host' = 'world-history-timeline.p.rapidapi.com'), 
                 content_type("application/octet-stream"))

# Veamos el resultado
response

# Extraigamos los datos
httr::content(response, "text")
httr::content(response, "parsed")
eventos <- httr::content(response, "parsed")

# Generemos la data 
data_1990 <- bind_rows(eventos)

data_1990 <- eventos %>% 
  bind_rows() %>% 
  mutate(momento = str_extract(Event, "^[^:]+:")) %>% 
  mutate(momento = str_remove_all(momento, pattern=":")) %>% 
  mutate(Event= str_remove_all(Event, "^[^:]+:")) %>% 
  mutate(Event= trimws(Event)) %>% 
  select(Event, Year, momento)

# Generalicemos en un proceso para varios años

# Definimos los parámetros
years <- as.character(1990:1999)
tabla_final <- tibble()
tabla_eventos <- tibble()

for(i in years){
  queryString <- list(year = as.character(i))
    
  response <- VERB("GET", url, query = queryString, add_headers('X-RapidAPI-Key' = 'c7b4cf08fdmsh183d3c50825def1p13f8fbjsnb74b69af4265', 
                                                                'X-RapidAPI-Host' = 'world-history-timeline.p.rapidapi.com'), 
                   content_type("application/octet-stream"))
  
  
  eventos <- httr::content(response, "parsed")
  
  tabla_eventos <- eventos %>% 
    bind_rows() %>% 
    mutate(momento = str_extract(Event, "^[^:]+:")) %>% 
    mutate(momento = str_remove_all(momento, pattern=":")) %>% 
    mutate(Event= str_remove_all(Event, "^[^:]+:")) %>% 
    mutate(Event= trimws(Event)) %>% 
    select(Event, Year, momento)
  
  tabla_final <- bind_rows(tabla_final, tabla_eventos)
  
}

glimpse(tabla_final) # Vemos el resultado

## 3.2 wbstats ----
# http://gshs-ornl.github.io/wbstats/
# Esta es una API de acceso gratuito 
# Ojo que no es una API del banco mundial 

remotes::install_github("nset-ornl/wbstats") # Vamos a instalar la versión más actualizada de la librería
library(wbstats)

# Veamos que información podemos extraer 
str(wb_cachelist, max.level = 1)

cache <- wb_cache()

# Algunas fuentes de información
# Las búsquedas se deben realizar en ingles
cache$countries
cache$countries$country

cache$indicators # Me permite ver los ID de los indicadores

cache$sources # Fuentes y actualizaciones
min(cache$sources$last_updated)
max(cache$sources$last_updated)

cache$topics
cache$regions

# Realicemos una primera extracción 

# Veamos los indicadores disponibles
indicadores <- cache$indicators

indicadores_salud1 <- wb_search("health", extra = TRUE, fields = "topics")
indicadores_salud2 <- wb_search("health|woman", extra = TRUE, fields = "indicator")

var_interes <- c(
  life_exp = "SP.DYN.LE00.IN", 
  gdp_capita ="NY.GDP.PCAP.CD", 
  pop = "SP.POP.TOTL",
  health_pay = "SH.XPD.TOTL.CD"
)

data_wb <- wb_data(var_interes, 
                   country = "countries_only",
                   start_date = 1990, end_date = 2025)

# Otra alternativa: https://www.r-project.org/nosvn/pandoc/WDI.html


## 3.3 SpotifyR ----

install.packages('spotifyr') # Paquete de R que extrae info de la api
install.packages("geniusr") # Herramientas para interactuar con APIS
library(spotifyr)
library(geniusr)

# Extramoe los datos de la cuenta (hay que crearse una cuenta de desarrollador)
Sys.setenv(SPOTIFY_CLIENT_ID = '') # Desde la cuenta de desarrollador de spotify
Sys.setenv(SPOTIFY_CLIENT_SECRET = '') # Desde la cuenta de desarrollador de spotify

# Generamos token de acceso
access_token <- get_spotify_access_token()

# Lista de generos que nos van a interesar
# Aplicaremos una lista reducida para no demandar tanto a la API
generos <- c('rap', 'rock', 'latin')# Para cada género tendremos 4 subgeneros

# Agregue más subgeneros para tener mayor información.
subgeneros <- data.frame(genero = c(rep('rap',2), rep('rock',2), rep('latin',2)),
                         subgenero = c('hip hop', 'trap', 
                                       'classic rock','hard rock',
                                       'tropical', 'reggaeton'),
                         stringsAsFactors = FALSE)

playlist_ids <- tibble() # Creamos una tabla vacía para guardar la información de las 20 canciones de estos playlist.

# Aplicamos nuestra primera interación.
# Objetivo: obtener información de las canciones de las playlist por generos
for(g in seq_along(subgeneros$subgenero)){
  
  out <- search_spotify(q = subgeneros$subgenero[g], type = 'playlist', market = 'CL', limit = 20) # Obtengo las playlist para el contexto de Chile (CL)
  out <- out %>%
    select(name, id) %>% # Selecciono solo el nombre de la canción con su identificador único.
    mutate(subgenero = subgeneros$subgenero[g], # Agregamos una colmuna con el subgenero
           genero = subgeneros$genero[g]) # Agregamos una columna con el género
  
  playlist_ids <- rbind(playlist_ids, out)  # Unimos con el data frame vacío de la línea 55
}

playlist_ids

# Obtenemos los ids de cada canción para generar la extracción 
playlist_songs <- NULL # Generamos un nuevo objeto vacío

for(i in seq_along(playlist_ids$id)){ # Para cada una de las canciones de for anterior haremos lo siguiente
  
  out <- get_playlist_tracks(playlist_id = playlist_ids$id[i]) # Obtener toda la información de la canción a partir del id. 
  
  out <- out %>%
    filter(!is.na(track.id)) %>% # Filtramos por información id no identificada.
    unnest(cols = 'track.artists') %>% # Sacamos la información de la lista track.artists
    group_by(track.id) %>% # Agrupamos para limpiar los duplicados
    mutate(row_number = 1:n(), 
           track.artist = name) %>% # Generamos un conteo ordenado por grupo para luego filtrar por el primer caso
    ungroup() %>%
    filter(row_number == 1) %>% # Nos quedamos con el primer caso que representa la fila no duplicada
    select(track.id, track.name, track.artist, track.popularity, track.album.id, track.album.name, track.album.release_date) %>% # Nos quedamos con las variables relevantes
    mutate(playlist_name = playlist_ids$name[i], # Agregamos una columna con el nombre de la canción
           playlist_id = playlist_ids$id[i],  # Agregamos una columna con el id
           playlist_genero = playlist_ids$genero[i],  # Agregamos una columna con el genero
           playlist_subgenero = playlist_ids$subgenero[i])   # Agregamos una columna con el subgenero
  
  playlist_songs <- rbind(playlist_songs, out) # Unimos con nuestro objeto de arranque vacío
  
}

playlist_songs

# Obtengo las características de las canciones 
# Función que genera la extracción a partir de los identificadores de las canciones 
get_track_features <- function(ids) {
  
  ids <- ids[!is.na(ids)] # limpio mis ids missing 
  len <- length(ids)  # veo el lago de esos ids
  reps <- floor(len/100) * 100 # vemos cuantas veces repetiremos el proceso
  intervalo <- c(seq(from = 0, to = reps, by = 100), len) # un intervalo de repeticiones
  
  data <- data.frame()  # dataframe vacio
  for(r in seq_along(intervalo)){
    inicio <- intervalo[r] # inicio de la extracción 
    fin <- intervalo[r + 1] - 1 # fin de la extracción
    if(is.na(fin)) break # cuando termina no tengo más obs por ende tengo que decirle "break"
    
    info <- get_track_audio_features(ids = ids[inicio:fin]) # Con la info extraigo del id 
    data <- rbind(data, info) # agrego a este objeto vacio de datos la información
    
  }
  
  return(data)
  
}

# Aplico mi función para realizar la extracción con la información de las canciones
head(playlist_songs$track.id) # Aquí están los ids de las canciones que va a utilizar

playlist_audio <- get_track_features(ids = playlist_songs$track.id)

playlist_audio

# Unimos ambas bases de datos: canciones con características a partir de los ids  
data_spotify <- playlist_songs %>%
  left_join(select(playlist_audio, -track_href, -uri, -analysis_url, -type, -time_signature), by = c('track.id' = 'id')) %>%
  unique() %>% # Eliminamos duplicados
  filter(!is.na(danceability)) # Quitamos si es que hay missing values

# Ajustamos los casos duplicados porque pueden estar en más de una lista
table(duplicated(data_spotify$track.id))

data_spotify <- data_spotify %>% 
  group_by(playlist_genero, playlist_subgenero, track.id) %>%
  mutate(row_number = 1:n()) %>% # Para limpiar duplicados
  ungroup() %>% 
  arrange(track.id) # Ordenamos por id

data_spotify <- data_spotify %>%   
  filter(row_number == 1) %>% # Filtramos los duplicados
  select(-row_number) # Eliminamos la variable generada para esto

head(data_spotify)
# Algunas variables importantes:  https://developer.spotify.com/documentation/web-api/reference/get-audio-features
# Acousticness: numérica, medida de confianza de 0,0 a 1,0 de si la pista es acústica. 1.0 representa una alta confianza en que la pista es acústica.
# Danceability: numérica, la bailabilidad describe qué tan adecuada es una pista para bailar en función de una combinación de elementos musicales que incluyen tempo, estabilidad del ritmo, fuerza del ritmo y regularidad general. Un valor de 0,0 es menos bailable y 1,0 es más bailable.
# Duration_ms: numérico, la duración de la pista en milisegundos.
# Duration_min: Numérico, la duración de la pista en minutos.
# Energy: numérica, la energía es una medida de 0,0 a 1,0 y representa una medida perceptiva de intensidad y actividad. Por lo general, las pistas enérgicas se sienten rápidas, fuertes y ruidosas. Por ejemplo, el death metal tiene mucha energía, mientras que un preludio de Bach tiene una puntuación baja en la escala. Las características perceptivas que contribuyen a este atributo incluyen el rango dinámico, el volumen percibido, el timbre, la tasa de inicio y la entropía general.
# Explicit: categórico, ya sea que la pista tenga o no una letra explícita (verdadero = sí, lo tiene; falso = no, no O desconocido).
# Instrumentalness: numérica, predice si una pista no contiene voces. Los sonidos “Ooh” y “aah” se tratan como instrumentales en este contexto. Las pistas de rap o de palabras habladas son claramente "vocales". Cuanto más cerca esté el valor de instrumentalidad de 1,0, mayor será la probabilidad de que la pista no contenga contenido vocal. Los valores superiores a 0,5 pretenden representar pistas instrumentales, pero la confianza es mayor a medida que el valor se acerca a 1,0.
# Liveness: Numérico, detecta la presencia de una audiencia en la grabación. Los valores de vivacidad más altos representan una mayor probabilidad de que la pista se interprete en vivo. Un valor superior a 0,8 proporciona una gran probabilidad de que la pista esté activa.
# Loudness: numérica, sonoridad general de una pista en decibelios (dB). Los valores de sonoridad se promedian en toda la pista y son útiles para comparar la sonoridad relativa de las pistas. El volumen es la cualidad de un sonido que es el principal correlato psicológico de la fuerza física (amplitud). Los valores típicos oscilan entre -60 y 0 db.
# Mode: Numérico, el modo indica la modalidad (mayor o menor) de una pista, el tipo de escala de la que se deriva su contenido melódico. Mayor está representado por 1 y menor es 0.
# Popularity: numérica, la popularidad de una pista es un valor entre 0 y 100, siendo 100 la más popular. La popularidad se calcula mediante un algoritmo y se basa, en su mayor parte, en el número total de reproducciones que ha tenido la pista y cuán recientes son esas reproducciones.
# Speechiness: numérico, Speechiness detecta la presencia de palabras habladas en una pista. Cuanto más parecida a la voz sea la grabación (por ejemplo, programa de entrevistas, audiolibro, poesía), más cerca de 1,0 será el valor del atributo. Los valores superiores a 0,66 describen pistas que probablemente estén formadas en su totalidad por palabras habladas. Los valores entre 0,33 y 0,66 describen pistas que pueden contener tanto música como voz, ya sea en secciones o en capas, incluidos casos como la música rap. Los valores por debajo de 0,33 probablemente representen música y otras pistas que no sean de voz.
# Tempo: numérico, tempo general estimado de una pista en pulsaciones por minuto (BPM). En terminología musical, el tempo es la velocidad o ritmo de una pieza dada y se deriva directamente de la duración promedio del tiempo.
# Valence: numérica, medida de 0,0 a 1,0 que describe la positividad musical transmitida por una pista. Las pistas con una valencia alta suenan más positivas (p. ej., felices, alegres, eufóricas), mientras que las pistas con una valencia baja suenan más negativas (p. ej., tristes, deprimidas, enfadadas). 

# Finalmente guardamos los datos de nuestra extracción
write.csv(data_spotify, 'output/extraccion_spotify.csv', row.names=FALSE)

# Grafiquemos
# Generemos una tabla para caracterizar a los artistas
tabla <- data_spotify %>% 
  filter(track.artist %in% c("Daddy Yankee", "Bad Bunny", "Guns N' Roses", "Queen")) %>% 
  select(track.artist, danceability:duration_ms) %>% 
  pivot_longer(!track.artist, names_to = "atributo", values_to = "value")

tabla %>% 
  ggplot(aes(x = value, fill=track.artist)) +
  geom_density(alpha = 0.5, color=NA) +
  facet_wrap(~stringr::str_to_title(atributo),  scales = 'free', ncol=2) +
  theme_light() +
  theme(plot.title = element_blank(),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        strip.text = element_text(color = "black"),
        strip.background = element_rect(fill="white", color = "gray25"),
        legend.position = "top",
        legend.title = element_blank())

########################################################################/
# Otros ejemplos con httr -------------
########################################################################/

# Recuerde siempre loggearse y busca la ventana de desarrolladores para obtener la:
# SIGN-UP-FOR-KEY: clave de acceso a la API (es personalizada)
# Pueden revisar más aquí 
# https://rapidapi.com/hub

## Venta de libros ----

url <- "https://books-search.p.rapidapi.com/complete"

queryString <- list(query = "do epic shit")

response <- VERB("GET", url, query = queryString, add_headers('X-RapidAPI-Key' = 'SIGN-UP-FOR-KEY', 'X-RapidAPI-Host' = 'books-search.p.rapidapi.com'), content_type("application/octet-stream"))

content(response, "text")

## Youtube: estadísticas de videos ----

url <- "https://youtube-v2.p.rapidapi.com/video/data"

queryString <- list(video_id = "hs1W2KQluWA")

response <- VERB("GET", url, query = queryString, add_headers('X-RapidAPI-Key' = 'SIGN-UP-FOR-KEY', 'X-RapidAPI-Host' = 'youtube-v2.p.rapidapi.com'), content_type("application/octet-stream"))

content(response, "text")

## Instagram: estadísticas ----

url <- "https://instagram-statistics-api.p.rapidapi.com/search"

queryString <- list(
  page = "1",
  perPage = "10",
  sort = "-score",
  locations = "united-states",
  socialTypes = "INST,FB"
)

response <- VERB("GET", url, query = queryString, add_headers('X-RapidAPI-Key' = 'SIGN-UP-FOR-KEY', 'X-RapidAPI-Host' = 'instagram-statistics-api.p.rapidapi.com'), content_type("application/octet-stream"))

content(response, "text")

## Google: búsquedas ----
url <- "https://google-search74.p.rapidapi.com/"

queryString <- list(
  query = "Nike",
  limit = "10",
  related_keywords = "true"
)

response <- VERB("GET", url, query = queryString, add_headers('X-RapidAPI-Key' = 'SIGN-UP-FOR-KEY', 'X-RapidAPI-Host' = 'google-search74.p.rapidapi.com'), content_type("application/octet-stream"))

content(response, "text")

########################################################################/
# FIN DE LA CLASE ----
########################################################################/

